import { Router } from "./router.js";

// (1) Sidebar colapsado por defecto (sólo íconos)
document.documentElement.classList.add("sidebar-collapsed");

// (2) Iniciar router
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => Router.init());
} else {
  Router.init();
}
