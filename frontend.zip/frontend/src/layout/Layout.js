// (1) Importamos utilidades de DOM y constantes globales
import { $, html } from "../utils/dom.js";
import { APP_NAME, ROUTES, STORAGE_KEYS } from "../config.js";

// (1) Importamos createIcons + TODO el set de íconos
import {
  createIcons,
  icons,
} from "https://cdn.jsdelivr.net/npm/lucide@latest/+esm";
// (3) Función para construir el menú según rol -> lista de { href, icon, label }
function menu(role) {
  const common = [{ href: ROUTES.DASHBOARD, icon: "home", label: "Inicio" }]; // (4) Ítems comunes
  if (role === "gerente") {
    // (5) Menú Gerente
    return [
      ...common,
      { href: "#/dashboard/pagos", icon: "credit-card", label: "Pagos" },
      { href: "#/dashboard/clientes", icon: "users", label: "Clientes" },
      { href: "#/dashboard/reportes", icon: "bar-chart-3", label: "Reportes" },
      { href: "#/dashboard/ajustes", icon: "settings", label: "Ajustes" },
    ];
  }
  if (role === "operador") {
    // (6) Menú Operador
    return [
      ...common,
      { href: "#/dashboard/pagos", icon: "credit-card", label: "Pagos" },
      {
        href: "#/dashboard/cargar-pago",
        icon: "plus-circle",
        label: "Cargar pago",
      },
      { href: "#/dashboard/pendientes", icon: "clock", label: "Pendientes" },
    ];
  }
  // (7) Menú Cliente (default)
  return [
    ...common,
    { href: "#/dashboard/mis-pagos", icon: "receipt", label: "Mis pagos" },
    { href: "#/dashboard/mis-datos", icon: "user", label: "Mis datos" },
  ];
}

// (8) Navbar (header superior): botón menú, marca, rol y acciones (ajustes/tema/salir)
function navbar(role, user) {
  return html`
    <button
      id="btn-toggle-sidebar"
      class="icon-btn"
      aria-label="Alternar sidebar"
      title="Menú"
    >
      <i data-lucide="menu" data-lucide-size="22" data-lucide-stroke="2.25"></i>
      <!-- (9) Placeholder que Lucide reemplaza por SVG -->
    </button>
    <strong class="navbar-brand">${APP_NAME}</strong>
    <!-- (10) Marca -->
    <span class="nav-spacer"></span>
    <!-- (11) Empuja elementos a la derecha -->
    ${role ? `<span class="badge">Rol: ${role}</span>` : ""}
    <!-- (12) Rol actual -->
    <button
      id="btn-settings"
      class="icon-btn"
      aria-label="Ajustes"
      title="Ajustes"
    >
      <i
        data-lucide="settings"
        data-lucide-size="22"
        data-lucide-stroke="2.25"
      ></i>
      <!-- (13) Ícono ajustes -->
    </button>
    <button
      id="btn-theme"
      class="icon-btn"
      aria-label="Tema"
      title="Cambiar tema"
    >
      <i data-lucide="moon" data-lucide-size="22" data-lucide-stroke="2.25"></i>
      <!-- (14) Ícono tema (placeholder) -->
    </button>
    ${user
      ? html` <button
          id="btn-logout"
          class="icon-btn"
          aria-label="Salir"
          title="Salir"
        >
          <i
            data-lucide="log-out"
            data-lucide-size="22"
            data-lucide-stroke="2.25"
          ></i>
          <!-- (15) Ícono logout -->
        </button>`
      : ""}
  `;
}

// (16) Sidebar (lateral): sólo íconos visibles; label queda para escritorio expandido o accesibilidad
function sidebar(role, current) {
  const items = menu(role); // (17) Menú por rol
  const links = items
    .map(
      (i) => html`
        <li>
          <a
            class="side-link ${i.href === current ? "active" : ""}"
            href="${i.href}"
            title="${i.label}"
          >
            <i
              data-lucide="${i.icon}"
              data-lucide-size="22"
              data-lucide-stroke="2.25"
              aria-hidden="true"
            ></i>
            <!-- (18) Ícono -->
            <span class="side-label">${i.label}</span>
            <!-- (19) Label (puede ocultarse) -->
          </a>
        </li>
      `
    )
    .join(""); // (20) Unimos los <li>
  return html`<ul class="side-menu">
    ${links}
  </ul>`; // (21) Lista final
}

// (22) API pública del layout
export const Layout = {
  draw() {
    // (23) Dibuja header + sidebar en cada navegación
    const user = JSON.parse(localStorage.getItem(STORAGE_KEYS.USER) || "null"); // (24) Sesión
    const profile = JSON.parse(
      localStorage.getItem(STORAGE_KEYS.PROFILE) || "null"
    ); // (25) Perfil (/me)
    const role = profile?.role || user?.role || ""; // (26) Rol efectivo

    const header = $("#app-header"); // (27) Nodo header
    const aside = $("#app-sidebar"); // (28) Nodo sidebar
    if (header) header.innerHTML = navbar(role, user); // (29) Pintar navbar
    if (aside) aside.innerHTML = sidebar(role, location.hash); // (30) Pintar sidebar

    createIcons({
      icons,
      attrs: {
        class: "lucide", // aplica las reglas CSS nuevas
        "stroke-width": 1.75, // 1.5–1.8 suele verse más “prolijo” que 2 en UI
        "aria-hidden": "true",
      },
    });

    // (32) Alternar sidebar: colapsado (desktop) y drawer (mobile)
    $("#btn-toggle-sidebar")?.addEventListener("click", () => {
      document.documentElement.classList.toggle("sidebar-collapsed");
      document.documentElement.classList.toggle("sidebar-open");
    });

    // (33) Logout
    $("#btn-logout")?.addEventListener("click", () => {
      localStorage.clear();
      location.hash = ROUTES.LOGIN;
    });

    // (34) Cerrar drawer móvil al hacer click en un link
    aside?.addEventListener("click", (e) => {
      const a = e.target.closest("a");
      if (a) document.documentElement.classList.remove("sidebar-open");
    });
  },

  highlightActive() {
    // (35) Marca item activo + rehidrata íconos por si cambia el DOM
    const current = location.hash;
    document.querySelectorAll(".side-link").forEach((a) => {
      a.classList.toggle("active", a.getAttribute("href") === current);
    });
    createIcons({ icons }); // (3) rehidratar tras cambios de DOM
  },
};
