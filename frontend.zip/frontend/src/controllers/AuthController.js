import { $, on, mount } from "../utils/dom.js";
import { AuthModel } from "../models/AuthModel.js";
import { LoginView } from "../views/LoginView.js";
import { ROUTES } from "../config.js";

export const AuthController = {
  renderLogin(root) {
    mount(root, LoginView());
    const form = $("#form-login", root);
    const $error = $("#login-error", root);
    const $btn = $("#btn-login", root);
    const $pwd = $("#pwd", root);
    const $togglePwd = $("#btn-toggle-pwd", root);

    // Toggle mostrar/ocultar contraseña
    on($togglePwd, "click", () => {
      const isPwd = $pwd.type === "password";
      $pwd.type = isPwd ? "text" : "password";
      $togglePwd
        .querySelector("i")
        ?.setAttribute("data-lucide", isPwd ? "eye-off" : "eye");
      if (window.lucide && window.lucide.createIcons)
        window.lucide.createIcons();
    });

    on(form, "submit", async (e) => {
      e.preventDefault();
      $error.style.display = "none";
      $btn.disabled = true;

      const fd = new FormData(form);
      const email = (fd.get("email") || "").toString().trim();
      const documento = (fd.get("documento") || "")
        .toString()
        .replace(/\D+/g, "");
      const password = (fd.get("password") || "").toString().trim();

      if (!password || (!email && !documento)) {
        $error.textContent = "Completá contraseña y (email o documento).";
        $error.style.display = "";
        $btn.disabled = false;
        return;
      }

      try {
        await AuthModel.login({
          email: email || undefined,
          documento: documento || undefined,
          password,
        });
        await AuthModel.me();
        location.hash = ROUTES.DASHBOARD;
      } catch (err) {
        $error.textContent = err?.message || "Error de autenticación";
        $error.style.display = "";
      } finally {
        $btn.disabled = false;
      }
    });
  },
};
