import { html } from "../utils/dom.js";

export function LoginView() {
  return html`
    <section class="auth-card" aria-labelledby="ttl-login">
      <div class="auth-brand">
        <i
          data-lucide="log-in"
          data-lucide-size="22"
          data-lucide-stroke="2.25"
        ></i>
        <h1 id="ttl-login">Ingresar</h1>
      </div>
      <p class="auth-sub">
        Accedé con <strong>email</strong> o <strong>documento</strong>.
      </p>

      <form id="form-login" novalidate>
        <div class="field">
          <label>
            <span>Email</span>
            <input
              type="email"
              name="email"
              placeholder="tu@correo.com"
              autocomplete="username"
            />
          </label>
        </div>

        <div class="field">
          <label>
            <span>Documento</span>
            <input
              type="text"
              name="documento"
              maxlength="11"
              inputmode="numeric"
              placeholder="DNI sin puntos"
            />
          </label>
        </div>

        <div class="field pwd-wrap">
          <label>
            <span>Contraseña</span>
            <input
              id="pwd"
              type="password"
              name="password"
              autocomplete="current-password"
              required
              placeholder="••••••••"
            />
          </label>
          <button
            id="btn-toggle-pwd"
            class="toggle-pwd"
            type="button"
            aria-label="Mostrar u ocultar contraseña"
          >
            <i
              data-lucide="eye"
              data-lucide-size="18"
              data-lucide-stroke="2"
            ></i>
          </button>
        </div>

        <p id="login-error" role="alert" style="display:none"></p>

        <div class="actions">
          <button id="btn-login" class="btn-primary" type="submit">
            Entrar
          </button>
        </div>
        <p class="hint">
          Completá <em>email</em> <strong>o</strong> <em>documento</em> + tu
          contraseña.
        </p>
      </form>
    </section>
  `;
}
